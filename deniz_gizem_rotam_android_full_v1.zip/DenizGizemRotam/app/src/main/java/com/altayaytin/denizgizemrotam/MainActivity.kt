package com.altayaytin.denizgizemrotam

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query as RetrofitQuery
import java.util.concurrent.TimeUnit

const val APP_VERSION = "TAM SÜRÜM 1.1 • BUILD DÜZELTİLDİ"

enum class Freshness(val label: String) {
    LIVE("Canlı veri"), TODAY("Bugün güncellendi"), WEEK("Son 7 gün içinde doğrulandı"), OLD("Eski bilgi olabilir"), UNKNOWN("Doğrulanamadı")
}

enum class JewelryChance(val label: String) { LOW("Düşük"), MEDIUM("Orta"), HIGH("Yüksek") }

data class LiveSeaState(
    val airTempC: Double? = null,
    val seaTempC: Double? = null,
    val windKmh: Double? = null,
    val waveM: Double? = null,
    val rainMm: Double? = null,
    val freshness: Freshness = Freshness.UNKNOWN
)

data class Beach(
    val id: String,
    val name: String,
    val region: String,
    val latitude: Double,
    val longitude: Double,
    val bottom: String,
    val shallow: Boolean,
    val slowDeepening: Boolean,
    val usuallyCalm: Boolean,
    val free: Boolean,
    val crowd: Int,
    val oldUse: Boolean,
    val beachClubDensity: Int,
    val walkSearchSuitable: Boolean,
    val legalWarning: String? = null,
    val live: LiveSeaState = LiveSeaState()
)

data class FoodPlace(
    val name: String,
    val type: String,
    val region: String,
    val latitude: Double,
    val longitude: Double,
    val phone: String? = null,
    val freshness: Freshness = Freshness.UNKNOWN,
    val note: String = "Güncel fiyat bulunamadı. Telefonla fiyat sor."
)

data class MysteryPlace(
    val name: String,
    val type: String,
    val region: String,
    val latitude: Double,
    val longitude: Double,
    val history: String,
    val legend: String,
    val freshness: Freshness = Freshness.OLD
)

data class StayPlace(
    val name: String,
    val type: String,
    val region: String,
    val latitude: Double,
    val longitude: Double,
    val free: Boolean,
    val tentOk: Boolean,
    val carOk: Boolean,
    val safetyNote: String,
    val phone: String? = null,
    val nightlyPriceForTwo: String? = null,
    val freshness: Freshness = Freshness.UNKNOWN
)

data class RouteRequest(val start: String, val end: String, val days: Int, val vehicle: String, val maxKmPerDay: Int, val routeType: String, val pensionBudget: Int)
data class RouteDay(val day: Int, val beach: Beach, val food: FoodPlace, val mystery: MysteryPlace, val stay: StayPlace, val km: Int, val driveTime: String, val costEstimate: String)

object Scoring {
    fun beachScore(beach: Beach): Int {
        var score = 0
        if (beach.shallow) score += 25
        if (beach.bottom.contains("kum", true)) score += 25
        if (beach.slowDeepening) score += 20
        if (beach.usuallyCalm) score += 10
        if (beach.free) score += 5
        beach.live.waveM?.let { score += if (it <= 0.35) 15 else if (it <= 0.75) 6 else -12 }
        beach.live.windKmh?.let { score += if (it <= 15) 8 else if (it <= 25) 0 else -8 }
        return score.coerceIn(0, 100)
    }

    fun jewelryChance(beach: Beach): JewelryChance {
        var score = 0
        if (beach.bottom.contains("kum", true)) score += 20
        if (beach.shallow) score += 20
        if (beach.slowDeepening) score += 15
        if (beach.walkSearchSuitable) score += 15
        if (beach.oldUse) score += 10
        score += beach.crowd.coerceIn(0, 10)
        score += beach.beachClubDensity.coerceIn(0, 10)
        beach.live.waveM?.let { if (it <= 0.5) score += 10 }
        if (beach.legalWarning != null) score -= 30
        return when { score >= 70 -> JewelryChance.HIGH; score >= 40 -> JewelryChance.MEDIUM; else -> JewelryChance.LOW }
    }
}

object LocalData {
    val beaches = listOf(
        Beach("akyarlar", "Akyarlar", "Bodrum", 36.9717, 27.2964, "Kum", true, true, true, true, 8, true, 6, true),
        Beach("karaincir", "Karaincir", "Datça", 36.7133, 27.6898, "Kum", true, true, true, true, 7, true, 4, true),
        Beach("sevgi", "Sevgi Plajı", "Kuşadası", 37.7170, 27.2187, "Kum", true, true, true, true, 9, true, 8, true),
        Beach("altinkum", "Altınkum", "Didim", 37.3565, 27.2675, "Kum", true, true, true, true, 10, true, 9, true),
        Beach("sarigerme", "Sarıgerme", "Ortaca", 36.7158, 28.7040, "Kum", true, true, true, false, 8, true, 7, true),
        Beach("patara", "Patara", "Kaş", 36.2686, 29.3181, "Kum", true, true, false, false, 7, true, 2, true, "Patara çevresi arkeolojik/sit alanı hassasiyeti taşır. Dedektör kullanmadan önce yerel yasal durumu kontrol edin."),
        Beach("kaputas", "Kaputaş", "Kaş", 36.2283, 29.4508, "Kum/çakıl", false, false, false, true, 9, true, 1, false),
        Beach("icmeler", "İçmeler", "Marmaris", 36.8014, 28.2312, "Kum/çakıl", false, false, true, true, 9, true, 8, false),
        Beach("bitez", "Bitez", "Bodrum", 37.0324, 27.3884, "Kum", true, true, true, true, 8, true, 8, true),
        Beach("akyaka", "Akyaka", "Ula", 37.0534, 28.3248, "Kum", true, true, true, true, 8, true, 5, true)
    )

    val foods = listOf(
        FoodPlace("Merkez Esnaf Lokantası", "Esnaf lokantası", "Bodrum", 37.0380, 27.4305),
        FoodPlace("Ev Yemekleri Noktası", "Ev yemekleri", "Datça", 36.7274, 27.6848),
        FoodPlace("Uygun Market Piknik", "Market / Piknik", "Didim", 37.3750, 27.2670),
        FoodPlace("Küçük Kebapçı", "Kebap", "Tarsus", 36.9174, 34.8929),
        FoodPlace("Sahil Balık Ekmek", "Balık", "Kuşadası", 37.8600, 27.2600),
        FoodPlace("Kahvaltı ve Çay Noktası", "Kahvaltı", "Marmaris", 36.8550, 28.2700)
    )

    val mysteries = listOf(
        MysteryPlace("Didim Apollon Tapınağı", "Tapınak", "Didim", 37.3840, 27.2568, "Antik dünyanın önemli kehanet merkezlerinden biridir.", "Kehanet, yeraltı geçitleri ve saklı bilgi temalarıyla anılır."),
        MysteryPlace("Efes Yamaç Evleri", "Antik kent", "Selçuk", 37.9398, 27.3410, "Roma dönemi konut dokusunu gösterir.", "Semboller ve ev içi ritüel izleri merak uyandırır."),
        MysteryPlace("Cennet-Cehennem Obrukları", "Mağara/mitoloji", "Mersin", 36.4520, 34.1070, "Doğal çökük alanlar ve mağara sistemiyle bilinir.", "Typhon anlatılarıyla ilişkilendirilen mitolojik atmosfer taşır."),
        MysteryPlace("Tarsus Efsane Durakları", "Efsaneli şehir", "Tarsus", 36.9174, 34.8929, "Farklı uygarlıkların izlerini taşır.", "Şahmeran, gizli geçitler ve eski anlatılarla anılır."),
        MysteryPlace("Kaunos Antik Kenti", "Antik kent", "Dalyan", 36.8340, 28.6425, "Kaya mezarları ve antik liman dokusuyla önemlidir.", "Su, ölüm ve geçiş temalarıyla okunabilir."),
        MysteryPlace("Knidos Antik Kenti", "Antik kent", "Datça", 36.6850, 27.3745, "Antik liman ve tapınak dokusuyla bilinir.", "Deniz yolları, kutsal alan ve eski semboller açısından güçlü bir duraktır.")
    )

    val stays = listOf(
        StayPlace("Araçta Kalınabilecek Sahil Noktası", "Araçta kalınabilecek yer", "Datça", 36.7220, 27.6900, true, false, true, "Güncel durum doğrulanamadı. Gitmeden önce yerel yetkililerden bilgi alın."),
        StayPlace("Ücretsiz Kamp Kontrol Noktası", "Ücretsiz kamp noktası", "Didim", 37.3490, 27.2800, true, true, true, "Güncel kamp yasağı doğrulanmadı. Gitmeden önce belediye/jandarma bilgisi alın."),
        StayPlace("Ekonomik Pansiyon Adayı", "Pansiyon", "Bodrum", 37.0370, 27.4240, false, false, false, "Güncel fiyat bulunamadı. Fiyatı işletmeden doğrulayın.", nightlyPriceForTwo = null),
        StayPlace("En Yakın Konaklama Adayı", "Pansiyon", "Kuşadası", 37.8600, 27.2600, false, false, false, "Güncel fiyat bulunamadı. Fiyatı işletmeden doğrulayın.", nightlyPriceForTwo = null)
    )
}

data class OpenMeteoResponse(val current: Map<String, Double>? = null)

interface WeatherApi {
    @GET("v1/forecast")
    suspend fun currentWeather(@RetrofitQuery("latitude") latitude: Double, @RetrofitQuery("longitude") longitude: Double, @RetrofitQuery("current") current: String = "temperature_2m,wind_speed_10m,precipitation", @RetrofitQuery("timezone") timezone: String = "auto"): OpenMeteoResponse
}

interface MarineApi {
    @GET("v1/marine")
    suspend fun currentMarine(@RetrofitQuery("latitude") latitude: Double, @RetrofitQuery("longitude") longitude: Double, @RetrofitQuery("current") current: String = "wave_height,sea_surface_temperature", @RetrofitQuery("timezone") timezone: String = "auto"): OpenMeteoResponse
}

object NetworkModule {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC })
        .build()

    val weatherApi: WeatherApi = Retrofit.Builder().baseUrl("https://api.open-meteo.com/").client(client).addConverterFactory(MoshiConverterFactory.create()).build().create(WeatherApi::class.java)
    val marineApi: MarineApi = Retrofit.Builder().baseUrl("https://marine-api.open-meteo.com/").client(client).addConverterFactory(MoshiConverterFactory.create()).build().create(MarineApi::class.java)
}

@Entity(tableName = "cached_items")
data class CachedItem(@PrimaryKey val key: String, val payload: String, val updatedAt: Long)

@Dao
interface CacheDao {
    @Query("SELECT * FROM cached_items WHERE `key` = :key LIMIT 1")
    suspend fun get(key: String): CachedItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(item: CachedItem)
}

@Database(entities = [CachedItem::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() { abstract fun cacheDao(): CacheDao }

class RefreshWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = Result.success()
}

object RefreshScheduler {
    fun schedule(context: Context) {
        val request = PeriodicWorkRequestBuilder<RefreshWorker>(6, TimeUnit.HOURS).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("canli_veri", ExistingPeriodicWorkPolicy.UPDATE, request)
    }
}

class RotamRepository {
    suspend fun refreshBeaches(): List<Beach> = withContext(Dispatchers.IO) {
        LocalData.beaches.map { beach ->
            try {
                val weather = NetworkModule.weatherApi.currentWeather(beach.latitude, beach.longitude)
                val marine = NetworkModule.marineApi.currentMarine(beach.latitude, beach.longitude)
                beach.copy(live = LiveSeaState(
                    airTempC = weather.current?.get("temperature_2m"),
                    windKmh = weather.current?.get("wind_speed_10m"),
                    rainMm = weather.current?.get("precipitation"),
                    waveM = marine.current?.get("wave_height"),
                    seaTempC = marine.current?.get("sea_surface_temperature"),
                    freshness = Freshness.LIVE
                ))
            } catch (_: Exception) {
                beach.copy(live = beach.live.copy(freshness = Freshness.UNKNOWN))
            }
        }.sortedByDescending { Scoring.beachScore(it) }
    }

    fun createRoute(request: RouteRequest): List<RouteDay> {
        val days = request.days.coerceIn(1, 20)
        val beaches = LocalData.beaches.sortedByDescending { Scoring.beachScore(it) }
        val mysteries = if (request.routeType.contains("Keşif", true)) LocalData.mysteries else LocalData.mysteries.take(3)
        return (1..days).map { day ->
            val beach = beaches[(day - 1) % beaches.size]
            val food = LocalData.foods[(day - 1) % LocalData.foods.size]
            val mystery = mysteries[(day - 1) % mysteries.size]
            val stay = LocalData.stays[(day - 1) % LocalData.stays.size]
            val km = if (request.routeType.contains("Ekonomik", true)) (request.maxKmPerDay * 0.65).toInt().coerceAtLeast(45) else (request.maxKmPerDay * 0.85).toInt().coerceAtLeast(70)
            RouteDay(day, beach, food, mystery, stay, km, "${(km / 60).coerceAtLeast(1)} sa ${km % 60} dk", if (request.routeType.contains("Ekonomik", true)) "Düşük / doğrula" else "Orta / doğrula")
        }
    }
}

class AppViewModel : ViewModel() {
    private val repository = RotamRepository()
    var beaches by mutableStateOf(LocalData.beaches.sortedByDescending { Scoring.beachScore(it) })
        private set
    var routeDays by mutableStateOf<List<RouteDay>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var message by mutableStateOf("$APP_VERSION • Canlı veri Open-Meteo ile alınır. Fiyat ve yasak bilgisi uydurulmaz.")
        private set

    fun refreshBeaches() {
        viewModelScope.launch {
            loading = true
            message = "Canlı hava, rüzgâr, dalga ve deniz bilgisi güncelleniyor..."
            beaches = repository.refreshBeaches()
            loading = false
            message = "Güncelleme tamamlandı. Doğrulanamayan bilgi açıkça gösterilir."
        }
    }

    fun buildRoute(request: RouteRequest) {
        routeDays = repository.createRoute(request)
        message = "${request.days} günlük ${request.routeType} hazırlandı."
    }

    fun lightenToday() {
        routeDays = routeDays.mapIndexed { index, day -> if (index == 0) day.copy(km = (day.km * 0.65).toInt(), driveTime = "Hafifletildi") else day }
        message = "Bugün hafifletildi."
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        RefreshScheduler.schedule(this)
        setContent { DenizGizemTheme { DenizGizemApp() } }
    }
}

@Composable
fun DenizGizemTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF67DDE2)) else lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF006C70))
    MaterialTheme(colorScheme = colors, content = content)
}

enum class Screen(val label: String) { SEA("Deniz"), ROUTE("Rotam"), FOOD("Yemek"), MYSTERY("Gizem"), STAY("Konaklama") }

@Composable
fun DenizGizemApp(vm: AppViewModel = viewModel()) {
    var selected by remember { mutableStateOf(Screen.SEA) }
    Scaffold(
        topBar = { TopAppBar(title = { Text("Deniz ve Gizem Rotam") }, actions = { IconButton(onClick = vm::refreshBeaches) { Icon(Icons.Default.Refresh, contentDescription = "Canlı verileri yenile") } }) },
        bottomBar = {
            NavigationBar {
                Screen.entries.forEach { screen ->
                    NavigationBarItem(selected = selected == screen, onClick = { selected = screen }, icon = { Icon(iconFor(screen), contentDescription = screen.label) }, label = { Text(screen.label) })
                }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            AssistChip(Modifier.padding(12.dp), onClick = {}, label = { Text(vm.message) }, leadingIcon = { Icon(Icons.Default.Info, contentDescription = null) })
            when (selected) {
                Screen.SEA -> SeaScreen(vm)
                Screen.ROUTE -> RouteScreen(vm)
                Screen.FOOD -> FoodScreen()
                Screen.MYSTERY -> MysteryScreen()
                Screen.STAY -> StayScreen()
            }
        }
    }
}

fun iconFor(screen: Screen) = when (screen) {
    Screen.SEA -> Icons.Default.Search
    Screen.ROUTE -> Icons.Default.Directions
    Screen.FOOD -> Icons.Default.Star
    Screen.MYSTERY -> Icons.Default.Search
    Screen.STAY -> Icons.Default.Home
}

@Composable
fun SeaScreen(vm: AppViewModel) {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Deniz Bul", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Sığ, kumlu, yavaş derinleşen ve az dalgalı plajlar üst sıraya alınır.")
            if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
        }
        items(vm.beaches) { BeachCard(it) }
    }
}

@Composable
fun BeachCard(beach: Beach) {
    val context = LocalContext.current
    val score = Scoring.beachScore(beach)
    val chance = Scoring.jewelryChance(beach)
    ElevatedCard {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${beach.name} / ${beach.region}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("${beach.bottom} • ${if (beach.shallow) "Sığ" else "Derinleşebilir"} • ${if (beach.slowDeepening) "Yavaş derinleşir" else "Hızlı derinleşebilir"}")
                }
                Badge { Text("$score") }
            }
            Text("Dalga: ${beach.live.waveM?.let { "%.2f m".format(it) } ?: "Doğrulanamadı"} • Rüzgâr: ${beach.live.windKmh?.let { "%.0f km/sa".format(it) } ?: "Doğrulanamadı"}")
            Text("Hava: ${beach.live.airTempC?.let { "%.1f °C".format(it) } ?: "Doğrulanamadı"} • Deniz: ${beach.live.seaTempC?.let { "%.1f °C".format(it) } ?: "Doğrulanamadı"}")
            Text("Ücret: ${if (beach.free) "Ücretsiz / kontrol et" else "Ücretli olabilir"} • Kalabalık: ${beach.crowd}/10 • ${beach.live.freshness.label}")
            AssistChip(onClick = {}, label = { Text("Takı bulma tahmini: ${chance.label} — yalnızca tahmindir, garanti vermez.") }, leadingIcon = { Icon(Icons.Default.Warning, contentDescription = null) })
            beach.legalWarning?.let { Text(it, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold) }
            Button(onClick = { openNavigation(context, beach.latitude, beach.longitude, beach.name) }) { Icon(Icons.Default.Directions, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("Buraya Gidelim") }
        }
    }
}

@Composable
fun RouteScreen(vm: AppViewModel) {
    var start by remember { mutableStateOf("Tarsus") }
    var end by remember { mutableStateOf("Alaçatı") }
    var days by remember { mutableStateOf("10") }
    var vehicle by remember { mutableStateOf("Otomobil") }
    var maxKm by remember { mutableStateOf("220") }
    var routeType by remember { mutableStateOf("Ekonomik Rota") }
    var budget by remember { mutableStateOf("2000") }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Rotam", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            SimpleField("Başlangıç noktası", start) { start = it }
            SimpleField("Bitiş noktası", end) { end = it }
            SimpleField("Kaç günlük tatil", days) { days = it.filter(Char::isDigit) }
            SimpleField("Araç", vehicle) { vehicle = it }
            SimpleField("Günlük en fazla km", maxKm) { maxKm = it.filter(Char::isDigit) }
            SimpleField("Rota tipi", routeType) { routeType = it }
            SimpleField("Pansiyon azami bütçe", budget) { budget = it.filter(Char::isDigit) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.buildRoute(RouteRequest(start, end, days.toIntOrNull() ?: 10, vehicle, maxKm.toIntOrNull() ?: 220, routeType, budget.toIntOrNull() ?: 2000)) }) { Text("Rota Oluştur") }
                OutlinedButton(onClick = vm::lightenToday) { Text("Bugünü Hafiflet") }
            }
        }
        items(vm.routeDays) { RouteDayCard(it) }
    }
}

@Composable
fun RouteDayCard(day: RouteDay) {
    val context = LocalContext.current
    ElevatedCard {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${day.day}. Gün", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Sabah denizi: ${day.beach.name} • Takı tahmini: ${Scoring.jewelryChance(day.beach).label}")
            Text("Öğle yemeği: ${day.food.name} (${day.food.type}) — ${day.food.note}")
            Text("Tarih/Gizem: ${day.mystery.name} • ${day.mystery.type}")
            Text("Konaklama: ${day.stay.name} • ${day.stay.type}")
            Text("Günlük yol: ${day.km} km • Sürüş: ${day.driveTime} • Masraf: ${day.costEstimate}")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { openNavigation(context, day.beach.latitude, day.beach.longitude, day.beach.name) }) { Text("Plaja Git") }
                OutlinedButton(onClick = { openNavigation(context, day.mystery.latitude, day.mystery.longitude, day.mystery.name) }) { Text("Gizeme Git") }
            }
        }
    }
}

@Composable
fun FoodScreen() {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Uygun Yemek", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Güvenilir güncel fiyat yoksa fiyat uydurulmaz.") }
        items(LocalData.foods) { FoodCard(it) }
    }
}

@Composable
fun FoodCard(place: FoodPlace) {
    val context = LocalContext.current
    ElevatedCard {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(place.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("${place.type} • ${place.region} • ${place.freshness.label}")
            Text(place.note)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { openNavigation(context, place.latitude, place.longitude, place.name) }) { Text("Navigasyon") }
                OutlinedButton(onClick = { callPhone(context, place.phone) }) { Text("Ara") }
                OutlinedButton(onClick = { whatsappAsk(context, place.phone, "Merhaba, güncel fiyat bilgisi alabilir miyim?") }) { Text("WhatsApp") }
            }
        }
    }
}

@Composable
fun MysteryScreen() {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Tarih ve Gizem", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Tarihî bilgi ile efsane ayrı tutulur; doğrulanmamış yorum kesin gerçek gibi gösterilmez.") }
        items(LocalData.mysteries) { MysteryCard(it) }
    }
}

@Composable
fun MysteryCard(place: MysteryPlace) {
    val context = LocalContext.current
    ElevatedCard {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(place.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("${place.type} • ${place.region} • ${place.freshness.label}")
            Text("Tarihî bilgi: ${place.history}")
            Text("Efsane / yerel anlatı: ${place.legend}")
            Button(onClick = { openNavigation(context, place.latitude, place.longitude, place.name) }) { Text("Buraya Gidelim") }
        }
    }
}

@Composable
fun StayScreen() {
    var filter by remember { mutableStateOf("Fark etmez, en ucuz seçeneği göster") }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Bu Gece Nerede Kalalım?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            SimpleField("Seçenek", filter) { filter = it }
            Text("Elektrik, duş, tuvalet, ortak mutfak gibi bilgiler bu ekranda bilinçli olarak gösterilmez.")
        }
        items(LocalData.stays) { StayCard(it) }
    }
}

@Composable
fun StayCard(stay: StayPlace) {
    val context = LocalContext.current
    ElevatedCard {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stay.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("${stay.type} • ${stay.region}")
            Text("Ücretsiz mi? ${if (stay.free) "Evet / doğrula" else "Hayır veya fiyat belirsiz"}")
            Text("Çadır: ${if (stay.tentOk) "Olabilir" else "Hayır"} • Araçta kalma: ${if (stay.carOk) "Olabilir" else "Hayır"}")
            Text("Kamp yasağı: ${stay.freshness.label}")
            Text(stay.safetyNote)
            Text(stay.nightlyPriceForTwo ?: "Güncel fiyat bulunamadı. Fiyatı işletmeden doğrulayın.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { openNavigation(context, stay.latitude, stay.longitude, stay.name) }) { Text("Navigasyon") }
                OutlinedButton(onClick = { callPhone(context, stay.phone) }) { Text("Ara") }
                OutlinedButton(onClick = { whatsappAsk(context, stay.phone, "Merhaba, bu gece için iki kişilik fiyat ve müsaitlik sorabilir miyim?") }) { Text("WhatsApp") }
            }
        }
    }
}

@Composable
fun SimpleField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true)
}

fun openNavigation(context: Context, lat: Double, lon: Double, label: String) {
    val uri = Uri.parse("geo:$lat,$lon?q=$lat,$lon(${Uri.encode(label)})")
    context.startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW, uri), "Navigasyon seç"))
}

fun callPhone(context: Context, phone: String?) {
    if (!phone.isNullOrBlank()) context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
}

fun whatsappAsk(context: Context, phone: String?, text: String) {
    val encoded = Uri.encode(text)
    val uri = if (phone.isNullOrBlank()) Uri.parse("https://wa.me/?text=$encoded") else Uri.parse("https://wa.me/$phone?text=$encoded")
    context.startActivity(Intent(Intent.ACTION_VIEW, uri))
}
