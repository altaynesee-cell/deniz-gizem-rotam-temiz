package com.altayaytin.denizgizemrotam

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.BeachAccess
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DenizGizemTheme {
                DenizGizemApp()
            }
        }
    }
}

private val AppColors: ColorScheme = darkColorScheme(
    primary = Color(0xFF8ED6F1),
    onPrimary = Color(0xFF06202A),
    secondary = Color(0xFFE7C97D),
    background = Color(0xFF15171B),
    surface = Color(0xFF20252A),
    surfaceVariant = Color(0xFF293138),
    onBackground = Color(0xFFF1F2F4),
    onSurface = Color(0xFFF1F2F4),
    onSurfaceVariant = Color(0xFFD6DCE1),
    error = Color(0xFFFFB4AB)
)

@Composable
private fun DenizGizemTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AppColors, content = content)
}

private enum class AppTab(val label: String, val icon: ImageVector) {
    SEA("Deniz", Icons.Default.BeachAccess),
    ROUTE("Rotam", Icons.Default.AltRoute),
    FOOD("Yemek", Icons.Default.Restaurant),
    MYSTERY("Gizem", Icons.Default.Explore),
    STAY("Konak", Icons.Default.Hotel)
}

private data class GeoPoint(
    val name: String,
    val latitude: Double,
    val longitude: Double
)

private data class RouteStop(
    val day: Int,
    val name: String,
    val latitude: Double,
    val longitude: Double
)

private data class RoutePlan(
    val startName: String,
    val endName: String,
    val days: Int,
    val distanceKm: Int,
    val durationHours: Int,
    val stops: List<RouteStop>
)

private data class PlaceItem(
    val name: String,
    val subtitle: String,
    val latitude: Double,
    val longitude: Double,
    val priority: Int = 99,
    val note: String? = null
)

private data class SeaConditions(
    val weatherText: String,
    val airTemperature: Double?,
    val apparentTemperature: Double?,
    val windSpeed: Double?,
    val windGust: Double?,
    val waveHeight: Double?,
    val waveDirection: Double?,
    val wavePeriod: Double?,
    val seaTemperature: Double?
)

private enum class PoiCategory {
    BEACH,
    FOOD,
    MYSTERY,
    STAY
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DenizGizemApp() {
    val context = LocalContext.current
    var selectedTab by rememberSaveable { mutableStateOf(AppTab.ROUTE) }
    var routePlan by remember { mutableStateOf(RouteStore.load(context)) }
    var activeRegion by rememberSaveable {
        mutableStateOf(routePlan?.stops?.lastOrNull()?.name.orEmpty())
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                AppTab.values().forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = {
                            Text(
                                text = tab.label,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Clip
                            )
                        },
                        alwaysShowLabel = true
                    )
                }
            }
        }
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            color = MaterialTheme.colorScheme.background
        ) {
            when (selectedTab) {
                AppTab.ROUTE -> RouteScreen(
                    currentPlan = routePlan,
                    onPlanCreated = { plan ->
                        routePlan = plan
                        activeRegion = plan.stops.lastOrNull()?.name.orEmpty()
                        RouteStore.save(context, plan)
                    },
                    onOpenSection = { tab, region ->
                        activeRegion = region
                        selectedTab = tab
                    }
                )

                AppTab.SEA -> SeaScreen(
                    routePlan = routePlan,
                    activeRegion = activeRegion,
                    onRegionChanged = { activeRegion = it }
                )

                AppTab.FOOD -> PlacesScreen(
                    title = "Ekonomik Yemek",
                    description = "Esnaf lokantası, pide, döner, fırın ve hızlı yemek türleri üst sırada gösterilir.",
                    category = PoiCategory.FOOD,
                    routePlan = routePlan,
                    activeRegion = activeRegion,
                    onRegionChanged = { activeRegion = it }
                )

                AppTab.MYSTERY -> PlacesScreen(
                    title = "Tarih ve Gizem",
                    description = "Arkeolojik alan, ören yeri, müze, kale, mağara ve tarihî noktaları bulur.",
                    category = PoiCategory.MYSTERY,
                    routePlan = routePlan,
                    activeRegion = activeRegion,
                    onRegionChanged = { activeRegion = it }
                )

                AppTab.STAY -> PlacesScreen(
                    title = "Konaklama",
                    description = "Kamp, karavan alanı, pansiyon, hostel, motel ve otelleri listeler.",
                    category = PoiCategory.STAY,
                    routePlan = routePlan,
                    activeRegion = activeRegion,
                    onRegionChanged = { activeRegion = it }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RouteScreen(
    currentPlan: RoutePlan?,
    onPlanCreated: (RoutePlan) -> Unit,
    onOpenSection: (AppTab, String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var start by rememberSaveable { mutableStateOf(currentPlan?.startName.orEmpty()) }
    var end by rememberSaveable { mutableStateOf(currentPlan?.endName.orEmpty()) }
    var daysText by rememberSaveable { mutableStateOf(currentPlan?.days?.toString() ?: "5") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var plan by remember { mutableStateOf(currentPlan) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ScreenHeader(
                title = "Rotam",
                subtitle = "Başlangıç, bitiş ve gün sayısına göre gerçek yol hattı üzerinde günlük duraklar oluşturur."
            )
        }

        item {
            ElevatedCard(
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = start,
                        onValueChange = { start = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Başlangıç yeri") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = end,
                        onValueChange = { end = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Bitiş yeri") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = daysText,
                        onValueChange = { daysText = it.filter(Char::isDigit).take(2) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Kaç gün?") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Done
                        )
                    )
                    Button(
                        onClick = {
                            val days = daysText.toIntOrNull()?.coerceIn(2, 14)
                            if (start.isBlank() || end.isBlank() || days == null) {
                                error = "Başlangıç, bitiş ve 2–14 arasında gün sayısı gir."
                                return@Button
                            }
                            loading = true
                            error = null
                            scope.launch {
                                runCatching {
                                    ApiService.createRoute(start.trim(), end.trim(), days)
                                }.onSuccess { created ->
                                    plan = created
                                    onPlanCreated(created)
                                }.onFailure { throwable ->
                                    error = throwable.userMessage()
                                }
                                loading = false
                            }
                        },
                        enabled = !loading,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (loading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(Modifier.width(10.dp))
                            Text("Rota hazırlanıyor…")
                        } else {
                            Icon(Icons.Default.AltRoute, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Rota oluştur")
                        }
                    }
                }
            }
        }

        error?.let { message ->
            item { ErrorCard(message) }
        }

        plan?.let { route ->
            item {
                ElevatedCard(
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            "${route.startName} → ${route.endName}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "${route.days} gün • yaklaşık ${route.distanceKm} km • ${route.durationHours} saat sürüş",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Her durağın altındaki düğmelerle o bölgenin deniz, yemek, gizem ve konaklama sonuçlarına geçebilirsin.",
                            fontSize = 13.sp
                        )
                    }
                }
            }

            items(route.stops, key = { "${it.day}-${it.name}" }) { stop ->
                ElevatedCard {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            "${stop.day}. Gün",
                            color = MaterialTheme.colorScheme.secondary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(stop.name, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            AssistChip(
                                onClick = { onOpenSection(AppTab.SEA, stop.name) },
                                label = { Text("Deniz") },
                                leadingIcon = {
                                    Icon(Icons.Default.BeachAccess, null, Modifier.size(18.dp))
                                }
                            )
                            AssistChip(
                                onClick = { onOpenSection(AppTab.FOOD, stop.name) },
                                label = { Text("Yemek") },
                                leadingIcon = {
                                    Icon(Icons.Default.Restaurant, null, Modifier.size(18.dp))
                                }
                            )
                            AssistChip(
                                onClick = { onOpenSection(AppTab.MYSTERY, stop.name) },
                                label = { Text("Gizem") },
                                leadingIcon = {
                                    Icon(Icons.Default.Explore, null, Modifier.size(18.dp))
                                }
                            )
                            AssistChip(
                                onClick = { onOpenSection(AppTab.STAY, stop.name) },
                                label = { Text("Konak") },
                                leadingIcon = {
                                    Icon(Icons.Default.Hotel, null, Modifier.size(18.dp))
                                }
                            )
                            AssistChip(
                                onClick = {
                                    openMap(context, stop.latitude, stop.longitude, stop.name)
                                },
                                label = { Text("Harita") },
                                leadingIcon = {
                                    Icon(Icons.Default.Map, null, Modifier.size(18.dp))
                                }
                            )
                        }
                    }
                }
            }
        }

        item { AttributionFooter() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SeaScreen(
    routePlan: RoutePlan?,
    activeRegion: String,
    onRegionChanged: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by rememberSaveable { mutableStateOf(activeRegion) }
    var beaches by remember { mutableStateOf<List<PlaceItem>>(emptyList()) }
    var selectedPlace by remember { mutableStateOf<PlaceItem?>(null) }
    var conditions by remember { mutableStateOf<SeaConditions?>(null) }
    var loading by remember { mutableStateOf(false) }
    var conditionsLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(activeRegion) {
        if (activeRegion.isNotBlank() && activeRegion != query) query = activeRegion
    }

    fun search(region: String) {
        if (region.isBlank()) {
            error = "Bir il, ilçe veya sahil bölgesi yaz."
            return
        }
        loading = true
        error = null
        onRegionChanged(region)
        scope.launch {
            runCatching {
                val center = ApiService.geocode(region)
                val found = ApiService.searchPlaces(center, PoiCategory.BEACH)
                val target = found.firstOrNull()
                    ?: PlaceItem(center.name, "Bölge merkezi", center.latitude, center.longitude)
                val live = ApiService.getSeaConditions(target.latitude, target.longitude)
                Triple(found, target, live)
            }.onSuccess { result ->
                beaches = result.first
                selectedPlace = result.second
                conditions = result.third
            }.onFailure { throwable ->
                error = throwable.userMessage()
                beaches = emptyList()
                selectedPlace = null
                conditions = null
            }
            loading = false
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ScreenHeader(
                title = "Deniz Bul",
                subtitle = "Yazdığın bölgedeki gerçek plaj adlarını ve seçilen plajın güncel hava, rüzgâr, dalga ve deniz sıcaklığını getirir."
            )
        }

        item {
            RouteRegionSelector(
                routePlan = routePlan,
                activeRegion = activeRegion,
                onSelect = { region ->
                    query = region
                    search(region)
                }
            )
        }

        item {
            SearchBox(
                value = query,
                onValueChange = { query = it },
                label = "Bölge yaz: Bodrum, Çeşme, Kaş…",
                buttonText = "Plajları bul",
                loading = loading,
                onSearch = { search(query.trim()) }
            )
        }

        error?.let { item { ErrorCard(it) } }

        conditions?.let { live ->
            item {
                SeaConditionsCard(
                    placeName = selectedPlace?.name ?: query,
                    conditions = live
                )
            }
        }

        if (!loading && beaches.isEmpty() && error == null && query.isNotBlank()) {
            item {
                InfoCard("Arama yapınca gerçek plaj adları burada listelenecek.")
            }
        }

        items(beaches, key = { "${it.name}-${it.latitude}-${it.longitude}" }) { beach ->
            PlaceCard(
                place = beach,
                actionText = if (selectedPlace?.name == beach.name) "Koşullar gösteriliyor" else "Canlı koşulları göster",
                actionEnabled = !conditionsLoading,
                onAction = {
                    conditionsLoading = true
                    selectedPlace = beach
                    scope.launch {
                        runCatching {
                            ApiService.getSeaConditions(beach.latitude, beach.longitude)
                        }.onSuccess { conditions = it }
                            .onFailure { error = it.userMessage() }
                        conditionsLoading = false
                    }
                },
                onMap = { openMap(context, beach.latitude, beach.longitude, beach.name) }
            )
        }

        item {
            InfoCard(
                "Sığlık ve yavaş derinleşme bilgisi açık harita verilerinde çoğu plaj için bulunmaz. Uygulama kum etiketi bulunan plajları üst sıraya alır; son kararı sahada kontrol et."
            )
        }
        item { AttributionFooter() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlacesScreen(
    title: String,
    description: String,
    category: PoiCategory,
    routePlan: RoutePlan?,
    activeRegion: String,
    onRegionChanged: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by rememberSaveable(title) { mutableStateOf(activeRegion) }
    var results by remember { mutableStateOf<List<PlaceItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(activeRegion) {
        if (activeRegion.isNotBlank() && activeRegion != query) query = activeRegion
    }

    fun search(region: String) {
        if (region.isBlank()) {
            error = "Bir il, ilçe veya bölge yaz."
            return
        }
        loading = true
        error = null
        onRegionChanged(region)
        scope.launch {
            runCatching {
                val center = ApiService.geocode(region)
                ApiService.searchPlaces(center, category)
            }.onSuccess { found ->
                results = found
                if (found.isEmpty()) {
                    error = "Bu bölgede adlandırılmış sonuç bulunamadı. Yakındaki ilçe adını deneyebilirsin."
                }
            }.onFailure { throwable ->
                results = emptyList()
                error = throwable.userMessage()
            }
            loading = false
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenHeader(title, description) }

        item {
            RouteRegionSelector(
                routePlan = routePlan,
                activeRegion = activeRegion,
                onSelect = { region ->
                    query = region
                    search(region)
                }
            )
        }

        item {
            SearchBox(
                value = query,
                onValueChange = { query = it },
                label = "Bölge yaz",
                buttonText = when (category) {
                    PoiCategory.FOOD -> "Yemek yerlerini bul"
                    PoiCategory.MYSTERY -> "Yerleri keşfet"
                    PoiCategory.STAY -> "Konaklama bul"
                    PoiCategory.BEACH -> "Ara"
                },
                loading = loading,
                onSearch = { search(query.trim()) }
            )
        }

        error?.let { item { ErrorCard(it) } }

        if (!loading && results.isEmpty() && error == null) {
            item { InfoCard("Bölge yazıp arama yaptığında gerçek yer adları burada görünecek.") }
        }

        items(results, key = { "${it.name}-${it.latitude}-${it.longitude}" }) { place ->
            PlaceCard(
                place = place,
                actionText = null,
                onAction = null,
                onMap = { openMap(context, place.latitude, place.longitude, place.name) }
            )
        }

        if (category == PoiCategory.FOOD) {
            item {
                InfoCard(
                    "Fiyatlar gösterilmez. Sonuçlar türüne göre sıralanır; fırın, hızlı yemek, yerel mutfak ve esnaf tipi işletmeler öne alınır. Güncel menüyü gitmeden kontrol et."
                )
            }
        }
        item { AttributionFooter() }
    }
}

@Composable
private fun ScreenHeader(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(
            subtitle,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 22.sp
        )
    }
}

@Composable
private fun SearchBox(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    buttonText: String,
    loading: Boolean,
    onSearch: () -> Unit
) {
    ElevatedCard {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text(label) },
                singleLine = true,
                trailingIcon = {
                    if (value.isNotBlank()) {
                        IconButton(onClick = onSearch) {
                            Icon(Icons.Default.Refresh, contentDescription = "Ara")
                        }
                    }
                }
            )
            Button(
                onClick = onSearch,
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (loading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("Araştırılıyor…")
                } else {
                    Icon(Icons.Default.Place, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(buttonText)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RouteRegionSelector(
    routePlan: RoutePlan?,
    activeRegion: String,
    onSelect: (String) -> Unit
) {
    val stops = routePlan?.stops.orEmpty()
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Rotadaki bölgeler", fontWeight = FontWeight.Bold)
            if (stops.isEmpty()) {
                Text(
                    "Önce Rotam bölümünden bir rota oluştur. Sonra duraklara buradan tek dokunuşla bakabilirsin.",
                    fontSize = 13.sp
                )
            } else {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    stops.distinctBy { it.name }.forEach { stop ->
                        FilterChip(
                            selected = activeRegion == stop.name,
                            onClick = { onSelect(stop.name) },
                            label = { Text(stop.name, maxLines = 1) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaceCard(
    place: PlaceItem,
    actionText: String?,
    actionEnabled: Boolean = true,
    onAction: (() -> Unit)?,
    onMap: () -> Unit
) {
    ElevatedCard {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(place.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(
                place.subtitle,
                color = MaterialTheme.colorScheme.secondary,
                fontWeight = FontWeight.Medium
            )
            place.note?.let {
                Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onMap) {
                    Icon(Icons.Default.Map, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Haritada aç")
                }
                if (actionText != null && onAction != null) {
                    TextButton(onClick = onAction, enabled = actionEnabled) {
                        Text(actionText)
                    }
                }
            }
        }
    }
}

@Composable
private fun SeaConditionsCard(placeName: String, conditions: SeaConditions) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(placeName, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("Güncel koşullar", color = MaterialTheme.colorScheme.secondary)
            Text("Hava: ${conditions.weatherText}")
            Text(
                "Sıcaklık: ${conditions.airTemperature.format("°C")} • Hissedilen: ${conditions.apparentTemperature.format("°C")}"
            )
            Text(
                "Rüzgâr: ${conditions.windSpeed.format(" km/sa")} • Hamle: ${conditions.windGust.format(" km/sa")}"
            )
            Text(
                "Dalga: ${conditions.waveHeight.format(" m")} (${waveLabel(conditions.waveHeight)})"
            )
            Text(
                "Dalga yönü: ${conditions.waveDirection.format("°")} • Periyot: ${conditions.wavePeriod.format(" sn")}"
            )
            Text("Deniz sıcaklığı: ${conditions.seaTemperature.format("°C")}")
        }
    }
}

@Composable
private fun ErrorCard(message: String) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.14f)
        )
    ) {
        Text(
            message,
            modifier = Modifier.padding(16.dp),
            color = MaterialTheme.colorScheme.error
        )
    }
}

@Composable
private fun InfoCard(message: String) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Text(message, modifier = Modifier.padding(16.dp), fontSize = 14.sp)
    }
}

@Composable
private fun AttributionFooter() {
    Text(
        "Veriler: OpenStreetMap katkıcıları, Open-Meteo ve OSRM. Sonuçlar açık veri kapsamına göre değişebilir.",
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontSize = 12.sp,
        modifier = Modifier.padding(vertical = 8.dp)
    )
}

private object RouteStore {
    private const val PREFS = "deniz_gizem_route"
    private const val KEY_PLAN = "route_plan"

    fun save(context: Context, plan: RoutePlan) {
        val stops = JSONArray()
        plan.stops.forEach { stop ->
            stops.put(
                JSONObject()
                    .put("day", stop.day)
                    .put("name", stop.name)
                    .put("lat", stop.latitude)
                    .put("lon", stop.longitude)
            )
        }
        val json = JSONObject()
            .put("start", plan.startName)
            .put("end", plan.endName)
            .put("days", plan.days)
            .put("distanceKm", plan.distanceKm)
            .put("durationHours", plan.durationHours)
            .put("stops", stops)

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PLAN, json.toString())
            .apply()
    }

    fun load(context: Context): RoutePlan? {
        return runCatching {
            val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_PLAN, null) ?: return null
            val json = JSONObject(raw)
            val stopsArray = json.getJSONArray("stops")
            val stops = buildList {
                for (i in 0 until stopsArray.length()) {
                    val item = stopsArray.getJSONObject(i)
                    add(
                        RouteStop(
                            day = item.getInt("day"),
                            name = item.getString("name"),
                            latitude = item.getDouble("lat"),
                            longitude = item.getDouble("lon")
                        )
                    )
                }
            }
            RoutePlan(
                startName = json.getString("start"),
                endName = json.getString("end"),
                days = json.getInt("days"),
                distanceKm = json.optInt("distanceKm"),
                durationHours = json.optInt("durationHours"),
                stops = stops
            )
        }.getOrNull()
    }
}

private object ApiService {
    private const val USER_AGENT = "DenizGizemRotam/3.0 Android"

    suspend fun geocode(query: String): GeoPoint = withContext(Dispatchers.IO) {
        val encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.toString())
        val url = "https://geocoding-api.open-meteo.com/v1/search" +
            "?name=$encoded&count=5&language=tr&format=json&countryCode=TR"
        val json = getJson(url)
        val results = json.optJSONArray("results")
            ?: throw IllegalStateException("Konum bulunamadı: $query")
        if (results.length() == 0) throw IllegalStateException("Konum bulunamadı: $query")
        val item = results.getJSONObject(0)
        val nameParts = listOfNotNull(
            item.optString("name").takeIf { it.isNotBlank() },
            item.optString("admin2").takeIf { it.isNotBlank() },
            item.optString("admin1").takeIf { it.isNotBlank() }
        ).distinct()
        GeoPoint(
            name = nameParts.joinToString(" / ").ifBlank { query },
            latitude = item.getDouble("latitude"),
            longitude = item.getDouble("longitude")
        )
    }

    suspend fun createRoute(startQuery: String, endQuery: String, days: Int): RoutePlan =
        withContext(Dispatchers.IO) {
            val start = geocode(startQuery)
            val end = geocode(endQuery)
            val routeJson = getJson(
                "https://router.project-osrm.org/route/v1/driving/" +
                    "${start.longitude},${start.latitude};${end.longitude},${end.latitude}" +
                    "?overview=full&geometries=geojson&steps=false"
            )
            if (routeJson.optString("code") != "Ok") {
                throw IllegalStateException("Bu iki nokta arasında araç rotası oluşturulamadı.")
            }
            val route = routeJson.getJSONArray("routes").getJSONObject(0)
            val coordinates = route.getJSONObject("geometry").getJSONArray("coordinates")
            val geometry = buildList {
                for (i in 0 until coordinates.length()) {
                    val pair = coordinates.getJSONArray(i)
                    add(GeoPoint("", pair.getDouble(1), pair.getDouble(0)))
                }
            }
            if (geometry.size < 2) throw IllegalStateException("Rota geometrisi alınamadı.")

            val sampled = sampleRoute(geometry, days)
            val nearbyTowns = fetchNearbyTowns(sampled)
            val usedNames = mutableSetOf<String>()
            val stops = sampled.mapIndexed { index, point ->
                val forcedName = when (index) {
                    0 -> start.name
                    sampled.lastIndex -> end.name
                    else -> null
                }
                val nearest = nearbyTowns
                    .asSequence()
                    .map { it to haversineKm(point, it) }
                    .sortedBy { it.second }
                    .firstOrNull { (town, distance) ->
                        distance <= 100.0 && town.name.lowercase(Locale("tr", "TR")) !in usedNames
                    }?.first
                    ?: nearbyTowns.minByOrNull { haversineKm(point, it) }

                val stopName = forcedName
                    ?: nearest?.name
                    ?: "${index + 1}. gün durağı"
                usedNames += stopName.lowercase(Locale("tr", "TR"))
                RouteStop(index + 1, stopName, point.latitude, point.longitude)
            }

            RoutePlan(
                startName = start.name,
                endName = end.name,
                days = days,
                distanceKm = (route.optDouble("distance") / 1000.0).roundToInt(),
                durationHours = (route.optDouble("duration") / 3600.0).roundToInt(),
                stops = stops
            )
        }

    suspend fun searchPlaces(center: GeoPoint, category: PoiCategory): List<PlaceItem> =
        withContext(Dispatchers.IO) {
            val query = overpassQuery(center, category)
            val json = postOverpass(query)
            val elements = json.optJSONArray("elements") ?: JSONArray()
            val items = mutableListOf<PlaceItem>()
            val seen = mutableSetOf<String>()

            for (i in 0 until elements.length()) {
                val element = elements.getJSONObject(i)
                val tags = element.optJSONObject("tags") ?: continue
                val name = tags.optString("name:tr").ifBlank { tags.optString("name") }.trim()
                if (name.isBlank()) continue
                val normalized = name.lowercase(Locale("tr", "TR"))
                if (!seen.add(normalized)) continue

                val centerObject = element.optJSONObject("center")
                val lat = when {
                    element.has("lat") -> element.optDouble("lat", Double.NaN)
                    centerObject != null -> centerObject.optDouble("lat", Double.NaN)
                    else -> Double.NaN
                }
                val lon = when {
                    element.has("lon") -> element.optDouble("lon", Double.NaN)
                    centerObject != null -> centerObject.optDouble("lon", Double.NaN)
                    else -> Double.NaN
                }
                if (lat.isNaN() || lon.isNaN()) continue

                val meta = placeMeta(category, tags)
                items += PlaceItem(
                    name = name,
                    subtitle = meta.first,
                    latitude = lat,
                    longitude = lon,
                    priority = meta.second,
                    note = meta.third
                )
            }

            items.sortedWith(
                compareBy<PlaceItem> { it.priority }
                    .thenBy { haversineKm(center, GeoPoint(it.name, it.latitude, it.longitude)) }
                    .thenBy { it.name }
            ).take(35)
        }

    suspend fun getSeaConditions(latitude: Double, longitude: Double): SeaConditions =
        withContext(Dispatchers.IO) {
            val weather = getJson(
                "https://api.open-meteo.com/v1/forecast" +
                    "?latitude=$latitude&longitude=$longitude" +
                    "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,wind_gusts_10m" +
                    "&timezone=auto"
            ).optJSONObject("current") ?: JSONObject()

            val marine = runCatching {
                getJson(
                    "https://marine-api.open-meteo.com/v1/marine" +
                        "?latitude=$latitude&longitude=$longitude" +
                        "&current=wave_height,wave_direction,wave_period,sea_surface_temperature" +
                        "&cell_selection=sea&timezone=auto"
                ).optJSONObject("current") ?: JSONObject()
            }.getOrElse { JSONObject() }

            SeaConditions(
                weatherText = weatherCodeText(weather.optInt("weather_code", -1)),
                airTemperature = weather.optNullableDouble("temperature_2m"),
                apparentTemperature = weather.optNullableDouble("apparent_temperature"),
                windSpeed = weather.optNullableDouble("wind_speed_10m"),
                windGust = weather.optNullableDouble("wind_gusts_10m"),
                waveHeight = marine.optNullableDouble("wave_height"),
                waveDirection = marine.optNullableDouble("wave_direction"),
                wavePeriod = marine.optNullableDouble("wave_period"),
                seaTemperature = marine.optNullableDouble("sea_surface_temperature")
            )
        }

    private fun overpassQuery(center: GeoPoint, category: PoiCategory): String {
        val lat = center.latitude
        val lon = center.longitude
        return when (category) {
            PoiCategory.BEACH -> """
                [out:json][timeout:25];
                (
                  nwr(around:30000,$lat,$lon)["natural"="beach"];
                  nwr(around:30000,$lat,$lon)["leisure"="beach_resort"];
                );
                out center tags;
            """.trimIndent()

            PoiCategory.FOOD -> """
                [out:json][timeout:25];
                (
                  nwr(around:12000,$lat,$lon)["amenity"~"restaurant|fast_food|cafe|food_court"];
                  nwr(around:12000,$lat,$lon)["shop"~"bakery|deli"];
                );
                out center tags;
            """.trimIndent()

            PoiCategory.MYSTERY -> """
                [out:json][timeout:30];
                (
                  nwr(around:30000,$lat,$lon)["historic"];
                  nwr(around:30000,$lat,$lon)["site_type"="archaeological_site"];
                  nwr(around:30000,$lat,$lon)["tourism"~"museum|attraction"];
                  nwr(around:30000,$lat,$lon)["natural"="cave_entrance"];
                );
                out center tags;
            """.trimIndent()

            PoiCategory.STAY -> """
                [out:json][timeout:25];
                (
                  nwr(around:18000,$lat,$lon)["tourism"~"hotel|motel|guest_house|hostel|camp_site|caravan_site|apartment|chalet"];
                );
                out center tags;
            """.trimIndent()
        }
    }

    private fun placeMeta(category: PoiCategory, tags: JSONObject): Triple<String, Int, String?> {
        fun tag(key: String): String = tags.optString(key).lowercase(Locale.ROOT)
        return when (category) {
            PoiCategory.BEACH -> {
                val surface = tag("surface")
                val natural = tag("natural")
                val leisure = tag("leisure")
                when {
                    "sand" in surface -> Triple("Kumlu plaj", 0, "Kum etiketi açık harita verisinde kayıtlı.")
                    natural == "beach" -> Triple("Plaj", 1, null)
                    leisure == "beach_resort" -> Triple("Plaj tesisi", 2, null)
                    else -> Triple("Sahil", 3, null)
                }
            }

            PoiCategory.FOOD -> {
                val amenity = tag("amenity")
                val shop = tag("shop")
                val cuisine = tag("cuisine")
                val cuisineLabel = cuisine
                    .split(';', ',')
                    .filter { it.isNotBlank() }
                    .joinToString(", ") { it.replace('_', ' ').replaceFirstChar(Char::uppercase) }
                    .takeIf { it.isNotBlank() }

                when {
                    shop == "bakery" -> Triple("Fırın / unlu mamuller", 0, null)
                    amenity == "fast_food" -> Triple("Hızlı yemek", 1, cuisineLabel)
                    amenity == "food_court" -> Triple("Yemek alanı", 1, cuisineLabel)
                    cuisine.contains("pide") || cuisine.contains("kebab") || cuisine.contains("doner") ||
                        cuisine.contains("turkish") || cuisine.contains("regional") || cuisine.contains("soup") ->
                        Triple("Yerel mutfak", 2, cuisineLabel)
                    amenity == "restaurant" -> Triple("Lokanta / restoran", 3, cuisineLabel)
                    amenity == "cafe" -> Triple("Kafe", 4, cuisineLabel)
                    else -> Triple("Yeme içme", 5, cuisineLabel)
                }
            }

            PoiCategory.MYSTERY -> {
                val historic = tag("historic")
                val siteType = tag("site_type")
                val tourism = tag("tourism")
                val natural = tag("natural")
                when {
                    siteType == "archaeological_site" || historic == "archaeological_site" ->
                        Triple("Arkeolojik alan", 0, null)
                    historic == "ruins" -> Triple("Ören yeri / kalıntı", 1, null)
                    historic == "castle" || historic == "fort" -> Triple("Kale / savunma yapısı", 1, null)
                    natural == "cave_entrance" -> Triple("Mağara", 1, null)
                    historic.isNotBlank() -> Triple("Tarihî nokta", 2, historic.replace('_', ' '))
                    tourism == "museum" -> Triple("Müze", 3, null)
                    tourism == "attraction" -> Triple("Turistik / kültürel nokta", 4, null)
                    else -> Triple("Keşif noktası", 5, null)
                }
            }

            PoiCategory.STAY -> {
                when (tag("tourism")) {
                    "camp_site" -> Triple("Kamp alanı", 0, null)
                    "caravan_site" -> Triple("Karavan alanı", 0, null)
                    "hostel" -> Triple("Hostel", 1, null)
                    "guest_house" -> Triple("Pansiyon / konukevi", 1, null)
                    "motel" -> Triple("Motel", 2, null)
                    "apartment" -> Triple("Apart", 2, null)
                    "chalet" -> Triple("Bungalov / dağ evi", 2, null)
                    "hotel" -> Triple("Otel", 3, null)
                    else -> Triple("Konaklama", 4, null)
                }
            }
        }
    }

    private fun sampleRoute(points: List<GeoPoint>, count: Int): List<GeoPoint> {
        if (count <= 2) return listOf(points.first(), points.last())
        val cumulative = DoubleArray(points.size)
        for (i in 1 until points.size) {
            cumulative[i] = cumulative[i - 1] + haversineKm(points[i - 1], points[i])
        }
        val total = cumulative.last()
        if (total <= 0.0) return List(count) { index ->
            if (index == count - 1) points.last() else points.first()
        }

        return (0 until count).map { sampleIndex ->
            val target = total * sampleIndex / (count - 1).toDouble()
            var upper = cumulative.indexOfFirst { it >= target }
            if (upper <= 0) return@map points.first()
            if (upper == -1) return@map points.last()
            val lower = upper - 1
            val segment = cumulative[upper] - cumulative[lower]
            val ratio = if (segment == 0.0) 0.0 else (target - cumulative[lower]) / segment
            val a = points[lower]
            val b = points[upper]
            GeoPoint(
                name = "",
                latitude = a.latitude + (b.latitude - a.latitude) * ratio,
                longitude = a.longitude + (b.longitude - a.longitude) * ratio
            )
        }
    }

    private fun fetchNearbyTowns(points: List<GeoPoint>): List<GeoPoint> {
        val body = buildString {
            append("[out:json][timeout:30];(")
            points.forEach { point ->
                append("node(around:70000,${point.latitude},${point.longitude})")
                append("[\"place\"~\"city|town\"][\"name\"];")
            }
            append(");out body;")
        }
        return runCatching {
            val json = postOverpassBlocking(body)
            val elements = json.optJSONArray("elements") ?: JSONArray()
            buildList {
                val seen = mutableSetOf<String>()
                for (i in 0 until elements.length()) {
                    val element = elements.getJSONObject(i)
                    val tags = element.optJSONObject("tags") ?: continue
                    val name = tags.optString("name:tr").ifBlank { tags.optString("name") }.trim()
                    if (name.isBlank() || !seen.add(name.lowercase(Locale("tr", "TR")))) continue
                    add(
                        GeoPoint(
                            name = name,
                            latitude = element.optDouble("lat"),
                            longitude = element.optDouble("lon")
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun getJson(url: String): JSONObject {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15_000
            readTimeout = 35_000
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept", "application/json")
        }
        return connection.useJsonResponse()
    }

    private fun postOverpass(query: String): JSONObject = postOverpassBlocking(query)

    private fun postOverpassBlocking(query: String): JSONObject {
        val endpoints = listOf(
            "https://overpass-api.de/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter"
        )
        var lastError: Throwable? = null
        for (endpoint in endpoints) {
            try {
                val body = "data=" + URLEncoder.encode(query, StandardCharsets.UTF_8.toString())
                val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 15_000
                    readTimeout = 55_000
                    setRequestProperty("User-Agent", USER_AGENT)
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                }
                connection.outputStream.use { output ->
                    output.write(body.toByteArray(StandardCharsets.UTF_8))
                }
                return connection.useJsonResponse()
            } catch (throwable: Throwable) {
                lastError = throwable
            }
        }
        throw lastError ?: IllegalStateException("Açık harita servisine ulaşılamadı.")
    }

    private fun HttpURLConnection.useJsonResponse(): JSONObject {
        return try {
            val code = responseCode
            val stream = if (code in 200..299) inputStream else errorStream
            val text = stream?.use { input ->
                BufferedReader(InputStreamReader(input, StandardCharsets.UTF_8)).readText()
            }.orEmpty()
            if (code !in 200..299) {
                throw IllegalStateException("Servis yanıt vermedi (HTTP $code).")
            }
            JSONObject(text)
        } finally {
            disconnect()
        }
    }
}

private fun openMap(context: Context, latitude: Double, longitude: Double, label: String) {
    val encodedLabel = Uri.encode(label)
    val geoUri = Uri.parse("geo:$latitude,$longitude?q=$latitude,$longitude($encodedLabel)")
    val geoIntent = Intent(Intent.ACTION_VIEW, geoUri)
    val fallback = Intent(
        Intent.ACTION_VIEW,
        Uri.parse("https://www.google.com/maps/search/?api=1&query=$latitude,$longitude")
    )
    runCatching { context.startActivity(geoIntent) }
        .onFailure { context.startActivity(fallback) }
}

private fun Throwable.userMessage(): String {
    val raw = message.orEmpty()
    return when {
        raw.contains("Unable to resolve host", ignoreCase = true) ->
            "İnternet bağlantısı kurulamadı. Bağlantını kontrol edip tekrar dene."
        raw.contains("timed out", ignoreCase = true) || raw.contains("timeout", ignoreCase = true) ->
            "Veri servisi geç yanıt verdi. Birkaç saniye sonra yeniden dene."
        raw.isNotBlank() -> raw
        else -> "İşlem tamamlanamadı. Tekrar dene."
    }
}

private fun JSONObject.optNullableDouble(key: String): Double? {
    if (!has(key) || isNull(key)) return null
    val value = optDouble(key, Double.NaN)
    return value.takeUnless { it.isNaN() }
}

private fun Double?.format(suffix: String): String {
    return this?.let { String.format(Locale("tr", "TR"), "%.1f%s", it, suffix) } ?: "Veri yok"
}

private fun waveLabel(height: Double?): String {
    return when {
        height == null -> "veri yok"
        height <= 0.30 -> "çok sakin"
        height <= 0.70 -> "hafif dalgalı"
        height <= 1.20 -> "dalgalı"
        else -> "yüksek dalga"
    }
}

private fun weatherCodeText(code: Int): String {
    return when (code) {
        0 -> "Açık"
        1 -> "Çoğunlukla açık"
        2 -> "Parçalı bulutlu"
        3 -> "Kapalı"
        45, 48 -> "Sisli"
        in 51..57 -> "Çisenti"
        in 61..67 -> "Yağmurlu"
        in 71..77 -> "Karlı"
        in 80..82 -> "Sağanak"
        85, 86 -> "Kar sağanağı"
        95 -> "Gök gürültülü fırtına"
        96, 99 -> "Dolu ihtimalli fırtına"
        else -> "Güncel hava"
    }
}

private fun haversineKm(a: GeoPoint, b: GeoPoint): Double {
    val earthRadiusKm = 6371.0
    val dLat = Math.toRadians(b.latitude - a.latitude)
    val dLon = Math.toRadians(b.longitude - a.longitude)
    val lat1 = Math.toRadians(a.latitude)
    val lat2 = Math.toRadians(b.latitude)
    val value = sin(dLat / 2) * sin(dLat / 2) +
        cos(lat1) * cos(lat2) * sin(dLon / 2) * sin(dLon / 2)
    return 2 * earthRadiusKm * asin(sqrt(value))
}
