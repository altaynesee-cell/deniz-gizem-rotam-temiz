# Deniz ve Gizem Rotam — v6 Gezgin

Bu sürüm, kullanıcının cihaz konumuna bağlı kalmadan Türkiye'nin herhangi bir bölgesini araştırması ve kendi çok duraklı rotasını kurması için güncellendi.

## Rotam

- **Bana Rota Hazırla:** Başlangıç, bitiş ve 2–14 gün bilgisiyle yol üzerindeki günlük durakları planlar.
- **10 günlük Ege–Akdeniz turu:** Ayvalık/Assos hattından Antalya/Side hattına uzanan alternatif sahil planları oluşturur.
- **Kendi Rotamı Oluştur:** Şehir, ilçe, koy, plaj veya gezilecek yer adını doğrudan yazarak rotanın sonuna ekler.
- Seçilen duraklar yukarı/aşağı taşınabilir, silinebilir ve Google Haritalar'da tek rota olarak açılabilir.
- Otomatik rotanın tamamı da tek düğmeyle haritada çizilebilir.

## Yer adı düzeltmesi

- `Erdek / Erdek İlçesi / Balıkesir` gibi girişler otomatik olarak temizlenir.
- Aramada il bilgisi kullanılabilir; ekranda yalnızca `Erdek` veya `Fethiye` gibi sade bölge adı gösterilir.
- İlçe/il tekrarları ve `/` işaretleri geocoding öncesinde düzeltilir.

## Yemek

- Pastane, kafe, kahveci, unlu mamuller, tatlıcı, fırın, börekçi, burger, pizza, sushi, pub ve bar sonuçları elenir.
- Yalnızca esnaf lokantası, ev yemekleri, sulu yemek, tabldot, çorba, pide, lahmacun, kebap, döner, köfte, ocakbaşı ve benzeri sıcak yemek türleri listelenir.
- Fiyat uydurulmaz; işletme türüne göre “ekonomik aday” olarak işaretlenir.
- Sonuçlar yazılan bölgenin merkezine yakınlığa göre sıralanır.

## Deniz

- Özel beach club, resort, ücretli veya yalnızca müşterilere açık olarak etiketlenen yerler elenir.
- Her plaj/koy kartında açık veride bulunan veya bulunmayan bilgiler ayrı gösterilir:
  - Kum, çakıl, kayalık veya bilinmiyor
  - Ücret/erişim etiketi
  - Sığlık bilgisinin doğrulanıp doğrulanmadığı
  - Metal dedektör hobisi için uygunluk adayı
  - Duş, tuvalet, otopark ve cankurtaran bilgisi
- Eksik veri tahmin edilmez.

## Konaklama

- Kamp, karavan alanı, hostel, pansiyon, apart ve motel üst sıralara alınır.
- 4–5 yıldızlı, resort, spa ve lüks tesisler elenir.
- Fiyat uydurulmaz; sonuçlar bölgeye yakınlığa göre sıralanır.

## Veri kaynakları

- OpenStreetMap / Overpass API
- Nominatim ve Open-Meteo Geocoding
- Open-Meteo Weather / Marine
- OSRM rota servisi
