package com.altayaytin.denizgizemrotam

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

internal object ApiService {
    private const val USER_AGENT = "DenizGizemRotam/5.0 Android"
    private val trLocale = Locale("tr", "TR")

    suspend fun geocode(query: String): GeoPoint = withContext(Dispatchers.IO) {
        val normalized = when (query.trim().lowercase(trLocale)) {
            "ege", "ege bölgesi" -> "İzmir"
            "akdeniz", "akdeniz bölgesi" -> "Antalya"
            else -> query.trim()
        }
        runCatching { geocodeOpenMeteo(normalized) }
            .recoverCatching { geocodeNominatim(normalized) }
            .getOrElse { throw IllegalStateException("Konum bulunamadı: $query") }
    }

    suspend fun createSmartRoute(
        startQuery: String,
        endQuery: String,
        days: Int,
        variant: Int = 0
    ): RoutePlan = withContext(Dispatchers.IO) {
        val start = geocode(startQuery)
        val end = geocode(endQuery)
        val routeResult = requestRoute(listOf(start, end), includeGeometry = true)
        val geometry = routeResult.geometry
        if (geometry.size < 2) throw IllegalStateException("Rota geometrisi alınamadı.")

        val sampled = sampleRoute(geometry, days)
        val nearbyTowns = fetchNearbyTowns(sampled)
        val usedNames = mutableSetOf<String>()
        val anchors = sampled.mapIndexed { index, point ->
            when (index) {
                0 -> start
                sampled.lastIndex -> end
                else -> {
                    val choices = nearbyTowns
                        .asSequence()
                        .map { it to haversineKm(point, it) }
                        .filter { it.second <= 90.0 }
                        .filter { it.first.name.lowercase(trLocale) !in usedNames }
                        .sortedBy { it.second }
                        .take(4)
                        .toList()
                    val selected = choices.getOrNull((variant + index) % maxOf(1, choices.size))?.first
                        ?: choices.firstOrNull()?.first
                        ?: point.copy(name = "${index + 1}. gün bölgesi")
                    usedNames += selected.name.lowercase(trLocale)
                    selected
                }
            }
        }

        val candidateMap = runCatching { fetchTourCandidates(anchors) }
            .getOrDefault(emptyMap())
        val stops = buildStops(anchors, candidateMap, variant)

        RoutePlan(
            startName = start.name,
            endName = end.name,
            days = days,
            distanceKm = routeResult.distanceKm,
            durationHours = routeResult.durationHours,
            stops = stops,
            kind = RouteKind.CUSTOM,
            variant = variant
        )
    }

    suspend fun createAegeanMediterraneanTour(
        days: Int = 10,
        variant: Int = 0
    ): RoutePlan = withContext(Dispatchers.IO) {
        val primary = listOf(
            "Ayvalık", "Foça", "Çeşme", "Kuşadası", "Bodrum",
            "Marmaris", "Fethiye", "Kaş", "Kemer", "Antalya"
        )
        val alternative = listOf(
            "Assos", "Dikili", "Alaçatı", "Sığacık", "Didim",
            "Akyaka", "Dalyan", "Ölüdeniz", "Kalkan", "Side"
        )
        val names = sampleList(if (variant % 2 == 0) primary else alternative, days)
        val anchors = names.map { geocode(it) }
        val routeResult = requestRoute(anchors, includeGeometry = false)
        val candidateMap = runCatching { fetchTourCandidates(anchors) }
            .getOrDefault(emptyMap())
        val stops = buildStops(anchors, candidateMap, variant)

        RoutePlan(
            startName = anchors.first().name,
            endName = anchors.last().name,
            days = days,
            distanceKm = routeResult.distanceKm,
            durationHours = routeResult.durationHours,
            stops = stops,
            kind = RouteKind.AEGEAN_MEDITERRANEAN,
            variant = variant
        )
    }

    suspend fun searchPlaces(center: GeoPoint, category: PoiCategory): List<PlaceItem> =
        withContext(Dispatchers.IO) {
            val json = postOverpass(overpassQuery(center, category))
            val elements = json.optJSONArray("elements") ?: JSONArray()
            val items = mutableListOf<PlaceItem>()
            val seen = mutableSetOf<String>()

            for (index in 0 until elements.length()) {
                val element = elements.getJSONObject(index)
                val tags = element.optJSONObject("tags") ?: continue
                val name = readName(tags)
                if (name.isBlank()) continue
                val normalized = name.lowercase(trLocale)
                if (!seen.add(normalized)) continue
                val point = elementPoint(element) ?: continue
                parsePlace(name, point, tags, category)?.let(items::add)
            }

            items.sortedWith(
                compareBy<PlaceItem> { it.priority }
                    .thenBy { haversineKm(center, it.asGeoPoint()) }
                    .thenBy { it.name }
            ).take(40)
        }

    suspend fun getSeaConditions(latitude: Double, longitude: Double): SeaConditions =
        withContext(Dispatchers.IO) {
            val weather = getJson(
                "https://api.open-meteo.com/v1/forecast" +
                    "?latitude=$latitude&longitude=$longitude" +
                    "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,wind_gusts_10m" +
                    "&timezone=auto"
            ).optJSONObject("current") ?: JSONObject()

            val marine = runCatching {
                getJson(
                    "https://marine-api.open-meteo.com/v1/marine" +
                        "?latitude=$latitude&longitude=$longitude" +
                        "&current=wave_height,wave_direction,wave_period,sea_surface_temperature" +
                        "&cell_selection=sea&timezone=auto"
                ).optJSONObject("current") ?: JSONObject()
            }.getOrElse { JSONObject() }

            SeaConditions(
                weatherText = weatherCodeText(weather.optInt("weather_code", -1)),
                airTemperature = weather.optNullableDouble("temperature_2m"),
                apparentTemperature = weather.optNullableDouble("apparent_temperature"),
                windSpeed = weather.optNullableDouble("wind_speed_10m"),
                windGust = weather.optNullableDouble("wind_gusts_10m"),
                waveHeight = marine.optNullableDouble("wave_height"),
                waveDirection = marine.optNullableDouble("wave_direction"),
                wavePeriod = marine.optNullableDouble("wave_period"),
                seaTemperature = marine.optNullableDouble("sea_surface_temperature")
            )
        }

    private fun geocodeOpenMeteo(query: String): GeoPoint {
        val encoded = encode(query)
        val json = getJson(
            "https://geocoding-api.open-meteo.com/v1/search" +
                "?name=$encoded&count=10&language=tr&format=json&countryCode=TR"
        )
        val results = json.optJSONArray("results")
            ?: throw IllegalStateException("Konum bulunamadı")
        if (results.length() == 0) throw IllegalStateException("Konum bulunamadı")
        val item = results.getJSONObject(0)
        val displayName = item.optString("name").ifBlank { query }
        return GeoPoint(
            name = displayName,
            latitude = item.getDouble("latitude"),
            longitude = item.getDouble("longitude")
        )
    }

    private fun geocodeNominatim(query: String): GeoPoint {
        val json = getJsonArray(
            "https://nominatim.openstreetmap.org/search" +
                "?q=${encode(query)}&format=jsonv2&limit=5&countrycodes=tr&accept-language=tr"
        )
        if (json.length() == 0) throw IllegalStateException("Konum bulunamadı")
        val item = json.getJSONObject(0)
        return GeoPoint(
            name = item.optString("display_name").substringBefore(',').ifBlank { query },
            latitude = item.getString("lat").toDouble(),
            longitude = item.getString("lon").toDouble()
        )
    }

    private data class RouteResult(
        val distanceKm: Int,
        val durationHours: Int,
        val geometry: List<GeoPoint>
    )

    private fun requestRoute(points: List<GeoPoint>, includeGeometry: Boolean): RouteResult {
        if (points.size < 2) throw IllegalArgumentException("En az iki rota noktası gerekli.")
        val coordinates = points.joinToString(";") { "${it.longitude},${it.latitude}" }
        val overview = if (includeGeometry) "full" else "false"
        val json = getJson(
            "https://router.project-osrm.org/route/v1/driving/$coordinates" +
                "?overview=$overview&geometries=geojson&steps=false"
        )
        if (json.optString("code") != "Ok") {
            throw IllegalStateException("Bu noktalar arasında araç rotası oluşturulamadı.")
        }
        val route = json.getJSONArray("routes").getJSONObject(0)
        val geometry = if (includeGeometry) {
            val coordinatesJson = route.getJSONObject("geometry").getJSONArray("coordinates")
            buildList {
                for (index in 0 until coordinatesJson.length()) {
                    val pair = coordinatesJson.getJSONArray(index)
                    add(GeoPoint("", pair.getDouble(1), pair.getDouble(0)))
                }
            }
        } else {
            points
        }
        return RouteResult(
            distanceKm = (route.optDouble("distance") / 1000.0).roundToInt(),
            durationHours = (route.optDouble("duration") / 3600.0).roundToInt(),
            geometry = geometry
        )
    }

    private fun buildStops(
        anchors: List<GeoPoint>,
        candidates: Map<PoiCategory, List<PlaceItem>>,
        variant: Int
    ): List<RouteStop> = anchors.mapIndexed { index, anchor ->
        RouteStop(
            day = index + 1,
            name = anchor.name,
            latitude = anchor.latitude,
            longitude = anchor.longitude,
            beach = chooseCandidate(anchor, candidates[PoiCategory.BEACH].orEmpty(), variant + index, 65.0),
            food = chooseCandidate(anchor, candidates[PoiCategory.FOOD].orEmpty(), variant + index, 25.0),
            mystery = chooseCandidate(anchor, candidates[PoiCategory.MYSTERY].orEmpty(), variant + index, 60.0),
            stay = chooseCandidate(anchor, candidates[PoiCategory.STAY].orEmpty(), variant + index, 30.0)
        )
    }

    private fun chooseCandidate(
        anchor: GeoPoint,
        items: List<PlaceItem>,
        seed: Int,
        maxDistanceKm: Double
    ): PlaceItem? {
        val ranked = items
            .asSequence()
            .map { it to haversineKm(anchor, it.asGeoPoint()) }
            .filter { it.second <= maxDistanceKm }
            .sortedWith(compareBy<Pair<PlaceItem, Double>> { it.first.priority }.thenBy { it.second })
            .take(6)
            .toList()
        if (ranked.isEmpty()) return null
        val topPriority = ranked.first().first.priority
        val closeTop = ranked.filter { it.first.priority <= topPriority + 1 }.ifEmpty { ranked }
        return closeTop[Math.floorMod(seed, closeTop.size)].first
    }

    private fun fetchTourCandidates(anchors: List<GeoPoint>): Map<PoiCategory, List<PlaceItem>> {
        val query = buildString {
            append("[out:json][timeout:55];(")
            anchors.forEach { point ->
                val lat = point.latitude
                val lon = point.longitude
                append("nwr(around:32000,$lat,$lon)[\"natural\"=\"beach\"][\"name\"];")
                append("nwr(around:32000,$lat,$lon)[\"leisure\"=\"beach_resort\"][\"name\"];")
                append("nwr(around:9000,$lat,$lon)[\"amenity\"~\"restaurant|fast_food|food_court\"][\"name\"];")
                append("nwr(around:32000,$lat,$lon)[\"historic\"][\"name\"];")
                append("nwr(around:32000,$lat,$lon)[\"site_type\"=\"archaeological_site\"][\"name\"];")
                append("nwr(around:32000,$lat,$lon)[\"tourism\"~\"museum|attraction\"][\"name\"];")
                append("nwr(around:32000,$lat,$lon)[\"natural\"=\"cave_entrance\"][\"name\"];")
                append("nwr(around:14000,$lat,$lon)[\"tourism\"~\"hotel|motel|guest_house|hostel|camp_site|caravan_site|apartment|chalet\"][\"name\"];")
            }
            append(");out tags center 1000;")
        }
        val json = postOverpass(query)
        val elements = json.optJSONArray("elements") ?: JSONArray()
        val result = PoiCategory.values().associateWith { mutableListOf<PlaceItem>() }
        val seen = PoiCategory.values().associateWith { mutableSetOf<String>() }

        for (index in 0 until elements.length()) {
            val element = elements.getJSONObject(index)
            val tags = element.optJSONObject("tags") ?: continue
            val name = readName(tags)
            if (name.isBlank()) continue
            val point = elementPoint(element) ?: continue
            PoiCategory.values().forEach { category ->
                val place = parsePlace(name, point, tags, category) ?: return@forEach
                val key = name.lowercase(trLocale)
                if (seen.getValue(category).add(key)) result.getValue(category).add(place)
            }
        }
        return result
    }

    private fun overpassQuery(center: GeoPoint, category: PoiCategory): String {
        val lat = center.latitude
        val lon = center.longitude
        return when (category) {
            PoiCategory.BEACH -> """
                [out:json][timeout:30];
                (
                  nwr(around:40000,$lat,$lon)["natural"="beach"]["name"];
                  nwr(around:40000,$lat,$lon)["leisure"="beach_resort"]["name"];
                  nwr(around:40000,$lat,$lon)["natural"="bay"]["name"];
                );
                out tags center 300;
            """.trimIndent()

            PoiCategory.FOOD -> """
                [out:json][timeout:30];
                (
                  nwr(around:20000,$lat,$lon)["amenity"~"restaurant|fast_food|food_court"]["name"];
                );
                out tags center 450;
            """.trimIndent()

            PoiCategory.MYSTERY -> """
                [out:json][timeout:35];
                (
                  nwr(around:32000,$lat,$lon)["historic"]["name"];
                  nwr(around:32000,$lat,$lon)["site_type"="archaeological_site"]["name"];
                  nwr(around:32000,$lat,$lon)["tourism"~"museum|attraction"]["name"];
                  nwr(around:32000,$lat,$lon)["natural"="cave_entrance"]["name"];
                );
                out tags center 500;
            """.trimIndent()

            PoiCategory.STAY -> """
                [out:json][timeout:30];
                (
                  nwr(around:25000,$lat,$lon)["tourism"~"hotel|motel|guest_house|hostel|camp_site|caravan_site|apartment|chalet"]["name"];
                );
                out tags center 450;
            """.trimIndent()
        }
    }

    private fun parsePlace(
        name: String,
        point: GeoPoint,
        tags: JSONObject,
        category: PoiCategory
    ): PlaceItem? {
        fun tag(key: String): String = tags.optString(key).lowercase(Locale.ROOT)
        val normalizedName = name.lowercase(trLocale)
        val amenity = tag("amenity")
        val tourism = tag("tourism")
        val historic = tag("historic")
        val siteType = tag("site_type")
        val natural = tag("natural")
        val leisure = tag("leisure")
        val cuisine = tag("cuisine")
        val surface = tag("surface")

        val meta: Triple<String, Int, String?> = when (category) {
            PoiCategory.BEACH -> when {
                natural == "beach" && "sand" in surface -> Triple("Kumlu plaj", 0, "Kum etiketi açık haritada kayıtlı.")
                natural == "beach" -> Triple("Plaj", 1, null)
                natural == "bay" -> Triple("Koy", 1, null)
                leisure == "beach_resort" -> Triple("Plaj tesisi", 3, null)
                else -> return null
            }

            PoiCategory.FOOD -> {
                if (amenity !in setOf("restaurant", "fast_food", "food_court")) return null
                val excluded = listOf("pastane", "patisserie", "cafe", "kafe", "kahve", "tatlı", "dondurma", "waffle")
                if (excluded.any { it in normalizedName }) return null
                val cuisineText = cuisine.replace('_', ' ')
                val detail = cuisine
                    .split(';', ',')
                    .filter { it.isNotBlank() }
                    .joinToString(", ") { it.replace('_', ' ').replaceFirstChar(Char::uppercase) }
                    .takeIf { it.isNotBlank() }
                when {
                    listOf("esnaf", "ev yemek", "sulu yemek", "tabldot", "çorba").any { it in normalizedName } ->
                        Triple("Esnaf lokantası / ev yemekleri", 0, detail)
                    listOf("pide", "lahmacun", "kebap", "kebab", "döner", "doner", "köfte", "ocakbaşı").any { it in normalizedName || it in cuisineText } ->
                        Triple("Pide, kebap, döner veya köfte", 1, detail)
                    cuisineText.contains("turkish") || cuisineText.contains("regional") || cuisineText.contains("soup") ->
                        Triple("Yerel mutfak", 2, detail)
                    amenity == "fast_food" -> Triple("Hızlı ve pratik yemek", 3, detail)
                    amenity == "food_court" -> Triple("Yemek alanı", 4, detail)
                    else -> Triple("Lokanta / restoran", 5, detail)
                }
            }

            PoiCategory.MYSTERY -> when {
                siteType == "archaeological_site" || historic == "archaeological_site" -> Triple("Arkeolojik alan", 0, null)
                historic == "ruins" -> Triple("Ören yeri / kalıntı", 1, null)
                historic == "castle" || historic == "fort" -> Triple("Kale / savunma yapısı", 1, null)
                natural == "cave_entrance" -> Triple("Mağara", 1, null)
                historic.isNotBlank() -> Triple("Tarihî nokta", 2, historic.replace('_', ' '))
                tourism == "museum" -> Triple("Müze", 3, null)
                tourism == "attraction" -> Triple("Kültürel / turistik nokta", 4, null)
                else -> return null
            }

            PoiCategory.STAY -> when (tourism) {
                "camp_site" -> Triple("Kamp alanı", 0, "Araç veya çadır için uygunluk bilgisini işletmeden kontrol et.")
                "caravan_site" -> Triple("Karavan alanı", 0, null)
                "hostel" -> Triple("Hostel", 1, null)
                "guest_house" -> Triple("Pansiyon / konukevi", 1, null)
                "apartment" -> Triple("Apart", 2, null)
                "motel" -> Triple("Motel", 2, null)
                "chalet" -> Triple("Bungalov / dağ evi", 2, null)
                "hotel" -> Triple("Otel", 4, null)
                else -> return null
            }
        }

        return PlaceItem(
            name = name,
            subtitle = meta.first,
            latitude = point.latitude,
            longitude = point.longitude,
            category = category,
            priority = meta.second,
            note = meta.third
        )
    }

    private fun fetchNearbyTowns(points: List<GeoPoint>): List<GeoPoint> {
        val body = buildString {
            append("[out:json][timeout:35];(")
            points.forEach { point ->
                append("node(around:80000,${point.latitude},${point.longitude})")
                append("[\"place\"~\"city|town\"][\"name\"];")
            }
            append(");out body 350;")
        }
        return runCatching {
            val json = postOverpass(body)
            val elements = json.optJSONArray("elements") ?: JSONArray()
            buildList {
                val seen = mutableSetOf<String>()
                for (index in 0 until elements.length()) {
                    val element = elements.getJSONObject(index)
                    val tags = element.optJSONObject("tags") ?: continue
                    val name = readName(tags)
                    if (name.isBlank() || !seen.add(name.lowercase(trLocale))) continue
                    add(GeoPoint(name, element.optDouble("lat"), element.optDouble("lon")))
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun sampleRoute(points: List<GeoPoint>, count: Int): List<GeoPoint> {
        if (count <= 2) return listOf(points.first(), points.last())
        val cumulative = DoubleArray(points.size)
        for (index in 1 until points.size) {
            cumulative[index] = cumulative[index - 1] + haversineKm(points[index - 1], points[index])
        }
        val total = cumulative.last()
        if (total <= 0.0) return List(count) { if (it == count - 1) points.last() else points.first() }

        return (0 until count).map { sampleIndex ->
            val target = total * sampleIndex / (count - 1).toDouble()
            val upper = cumulative.indexOfFirst { it >= target }
            when {
                upper <= 0 -> points.first()
                upper == -1 -> points.last()
                else -> {
                    val lower = upper - 1
                    val segment = cumulative[upper] - cumulative[lower]
                    val ratio = if (segment == 0.0) 0.0 else (target - cumulative[lower]) / segment
                    val a = points[lower]
                    val b = points[upper]
                    GeoPoint(
                        "",
                        a.latitude + (b.latitude - a.latitude) * ratio,
                        a.longitude + (b.longitude - a.longitude) * ratio
                    )
                }
            }
        }
    }

    private fun <T> sampleList(items: List<T>, count: Int): List<T> {
        if (count >= items.size) return items
        if (count <= 1) return listOf(items.first())
        return (0 until count).map { index ->
            val raw = index * (items.lastIndex.toDouble() / (count - 1).toDouble())
            items[raw.roundToInt().coerceIn(0, items.lastIndex)]
        }.distinct().let { sampled ->
            if (sampled.size == count) sampled else items.take(count)
        }
    }

    private fun readName(tags: JSONObject): String =
        tags.optString("name:tr").ifBlank { tags.optString("name") }.trim()

    private fun elementPoint(element: JSONObject): GeoPoint? {
        val center = element.optJSONObject("center")
        val lat = when {
            element.has("lat") -> element.optDouble("lat", Double.NaN)
            center != null -> center.optDouble("lat", Double.NaN)
            else -> Double.NaN
        }
        val lon = when {
            element.has("lon") -> element.optDouble("lon", Double.NaN)
            center != null -> center.optDouble("lon", Double.NaN)
            else -> Double.NaN
        }
        return if (lat.isNaN() || lon.isNaN()) null else GeoPoint("", lat, lon)
    }

    private fun getJson(url: String): JSONObject = JSONObject(getText(url))

    private fun getJsonArray(url: String): JSONArray = JSONArray(getText(url))

    private fun getText(url: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15_000
            readTimeout = 40_000
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept", "application/json")
        }
        return connection.useTextResponse()
    }

    private fun postOverpass(query: String): JSONObject {
        val endpoints = listOf(
            "https://overpass-api.de/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter",
            "https://overpass.nchc.org.tw/api/interpreter"
        )
        var lastError: Throwable? = null
        endpoints.forEach { endpoint ->
            try {
                val body = "data=" + encode(query)
                val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 15_000
                    readTimeout = 65_000
                    setRequestProperty("User-Agent", USER_AGENT)
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                }
                connection.outputStream.use { output ->
                    output.write(body.toByteArray(StandardCharsets.UTF_8))
                }
                return JSONObject(connection.useTextResponse())
            } catch (throwable: Throwable) {
                lastError = throwable
            }
        }
        throw lastError ?: IllegalStateException("Açık harita servisine ulaşılamadı.")
    }

    private fun HttpURLConnection.useTextResponse(): String = try {
        val code = responseCode
        val stream = if (code in 200..299) inputStream else errorStream
        val text = stream?.use { input ->
            BufferedReader(InputStreamReader(input, StandardCharsets.UTF_8)).readText()
        }.orEmpty()
        if (code !in 200..299) throw IllegalStateException("Servis yanıt vermedi (HTTP $code).")
        text
    } finally {
        disconnect()
    }

    private fun encode(value: String): String =
        URLEncoder.encode(value, StandardCharsets.UTF_8.toString())
}

internal fun Throwable.userMessage(): String {
    val raw = message.orEmpty()
    return when {
        raw.contains("Unable to resolve host", ignoreCase = true) ->
            "İnternet bağlantısı kurulamadı. Bağlantını kontrol edip tekrar dene."
        raw.contains("timed out", ignoreCase = true) || raw.contains("timeout", ignoreCase = true) ->
            "Veri servisi geç yanıt verdi. Yeniden dene."
        raw.contains("HTTP 429", ignoreCase = true) ->
            "Harita servisi geçici olarak yoğun. Biraz sonra tekrar dene."
        raw.isNotBlank() -> raw
        else -> "İşlem tamamlanamadı. Tekrar dene."
    }
}

internal fun JSONObject.optNullableDouble(key: String): Double? {
    if (!has(key) || isNull(key)) return null
    val value = optDouble(key, Double.NaN)
    return value.takeUnless { it.isNaN() }
}

internal fun Double?.format(suffix: String): String =
    this?.let { String.format(Locale("tr", "TR"), "%.1f%s", it, suffix) } ?: "Veri yok"

internal fun waveLabel(height: Double?): String = when {
    height == null -> "veri yok"
    height <= 0.30 -> "çok sakin"
    height <= 0.70 -> "hafif dalgalı"
    height <= 1.20 -> "dalgalı"
    else -> "yüksek dalga"
}

internal fun weatherCodeText(code: Int): String = when (code) {
    0 -> "Açık"
    1 -> "Çoğunlukla açık"
    2 -> "Parçalı bulutlu"
    3 -> "Kapalı"
    45, 48 -> "Sisli"
    in 51..57 -> "Çisenti"
    in 61..67 -> "Yağmurlu"
    in 71..77 -> "Karlı"
    in 80..82 -> "Sağanak"
    85, 86 -> "Kar sağanağı"
    95 -> "Gök gürültülü fırtına"
    96, 99 -> "Dolu ihtimalli fırtına"
    else -> "Güncel hava"
}

internal fun haversineKm(a: GeoPoint, b: GeoPoint): Double {
    val earthRadiusKm = 6371.0
    val dLat = Math.toRadians(b.latitude - a.latitude)
    val dLon = Math.toRadians(b.longitude - a.longitude)
    val lat1 = Math.toRadians(a.latitude)
    val lat2 = Math.toRadians(b.latitude)
    val value = sin(dLat / 2) * sin(dLat / 2) +
        cos(lat1) * cos(lat2) * sin(dLon / 2) * sin(dLon / 2)
    return 2 * earthRadiusKm * asin(sqrt(value))
}

private fun PlaceItem.asGeoPoint(): GeoPoint = GeoPoint(name, latitude, longitude)
