# Deniz ve Gizem Rotam — v5

Bu sürüm, rota ve seçim ekranlarını baştan düzenler.

## Yeni rota sistemi

- **Ege’den Akdeniz’e 10 günlük hazır tur:** Sahil hattında günlük duraklar oluşturur.
- **Günlük gerçek seçenekler:** Her güne OpenStreetMap verilerinden plaj/koy, ekonomik yemek, tarihî-gizemli yer ve konaklama eklemeye çalışır.
- **Alternatif rota:** Aynı plan için farklı sahil durakları ve farklı yer seçenekleri getirir.
- **Kendi başlangıç ve bitişin:** 2–14 gün arasında günlük gezi planı oluşturur.
- **Kendi rotam:** Deniz, Yemek, Gizem ve Konak ekranlarından istediğin yerleri seçip sıralayabilir ve Google Haritalar’da rota olarak açabilirsin.

## Arama ekranları

- Aramalar telefonun konumuna bağlı değildir. Türkiye’de istediğin şehir, ilçe veya bölgeyi yazabilirsin.
- Yemek ekranında pastane ve kafeler elenir; esnaf lokantası, ev yemekleri, pide, kebap, döner ve köfte türleri öne alınır.
- Konaklama ekranında kamp, karavan alanı, pansiyon, hostel, apart, motel ve oteller listelenir.
- Deniz ekranında plaj ve koylar ile güncel hava, rüzgâr, dalga ve deniz sıcaklığı gösterilir.

## Veri kaynakları

- OpenStreetMap / Overpass API
- Open-Meteo Geocoding, Weather ve Marine API
- OSRM rota servisi

Açık veride bulunmayan fiyat, kesin sığlık veya kesin ekonomik olma bilgisi uydurulmaz.
