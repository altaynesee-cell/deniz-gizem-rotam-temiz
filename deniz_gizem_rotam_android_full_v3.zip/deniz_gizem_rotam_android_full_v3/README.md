# Deniz ve Gizem Rotam v3

Bu sürümde sabit Akyarlar ve örnek rota verileri kaldırıldı.

## Çalışan özellikler

- **Rotam:** Başlangıç, bitiş ve gün sayısını kullanır. Open-Meteo ile konumları bulur, OSRM ile gerçek araç rotasını çıkarır ve rota hattındaki şehirleri günlük duraklara dönüştürür.
- **Ortak rota:** Oluşturulan rota telefonda saklanır. Deniz, Yemek, Gizem ve Konak ekranlarında rota durakları seçilebilir.
- **Duraktan bölüme geçiş:** Her günlük durak kartından doğrudan Deniz, Yemek, Gizem veya Konak ekranına geçilir.
- **Deniz:** OpenStreetMap üzerinden gerçek plaj adlarını getirir. Seçilen plaj için Open-Meteo üzerinden güncel hava, rüzgâr, dalga ve deniz sıcaklığını gösterir.
- **Yemek:** Gerçek işletme adlarını getirir. Fırın, hızlı yemek, yerel mutfak ve esnaf tipi seçenekleri öne alır. Fiyat veya telefon numarası göstermez.
- **Gizem:** Arkeolojik alan, ören yeri, kale, müze, mağara ve tarihî noktaları getirir.
- **Konak:** Kamp, karavan alanı, pansiyon, hostel, motel, apart ve otelleri getirir.
- **Harita:** Her sonuç harita uygulamasında açılabilir.

## Veri kaynakları

- OpenStreetMap / Overpass API
- Open-Meteo Geocoding, Weather ve Marine API
- OSRM rota servisi

Açık veri kapsamı bölgeden bölgeye değişebilir. Uygulama fiyat, sığlık ve yavaş derinleşme gibi güvenilir açık verisi bulunmayan bilgileri uydurmaz.
